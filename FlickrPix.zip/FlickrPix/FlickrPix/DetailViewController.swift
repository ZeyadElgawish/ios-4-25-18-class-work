//
//  DetailViewController.swift
//  FlickrPix
//
//  Created by Zeyad Elgawish on 4/25/19.
//  Copyright © 2019 Farmingdale State College. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var TitleLable: UILabel!
    @IBOutlet weak var OwnerLable: UILabel!
    @IBOutlet var DestLable: UIView!
    @IBOutlet weak var ImageView: UIImageView!
    var theFlickrPicture: FlickrPicture?
 
    override func viewDidLoad() {
        super.viewDidLoad()
      
    TitleLable.text = theFlickrPicture?.title
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
}
