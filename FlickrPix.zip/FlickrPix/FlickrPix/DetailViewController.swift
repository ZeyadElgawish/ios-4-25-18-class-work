//
//  DetailViewController.swift
//  FlickrPix
//
//  Created by Zeyad Elgawish on 4/25/19.
//  Copyright © 2019 Farmingdale State College. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var TitleLable: UILabel!
    @IBOutlet weak var OwnerLable: UILabel!
    @IBOutlet weak var ImageView: UIImageView!
    var theFlickerPic : FlickrPicture?
 
    override func viewDidLoad() {
        super.viewDidLoad()
       TitleLable.text = theFlickerPic?.title
       OwnerLable.text = theFlickerPic?.owner

        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
}
