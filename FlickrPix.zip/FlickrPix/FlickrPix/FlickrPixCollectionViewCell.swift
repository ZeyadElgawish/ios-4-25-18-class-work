//
//  FlickrPixCollectionViewCell.swift
//  FlickrPix
//
//  Created by David Gerstl on 4/16/19.
//  Copyright © 2019 Farmingdale State College. All rights reserved.
//

import UIKit

class FlickrPixCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var theImage: UIImageView!
    
}
