//
//  FlickrPictureViewController.swift
//  FlickrPix
//
//  Created by David Gerstl on 4/9/19.
//  Copyright © 2019 Farmingdale State College. All rights reserved.
//

import UIKit

class FlickrPictureViewController: UIViewController {
    let myPictures = FlickrPictureCollection()
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        myPictures.getRecent()
        print("I'm in \(#file) at line \(#line)")
        // myPictures.getWith(searchTerm: "sunny")
        print("I'm in \(#file). I have \(myPictures.currentPhotos?.count) pictures")
        sleep(3)
        print("I'm at line \(#line). I have \(myPictures.currentPhotos?.count) pictures")
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
