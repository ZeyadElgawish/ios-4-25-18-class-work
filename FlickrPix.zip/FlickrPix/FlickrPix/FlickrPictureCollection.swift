//
//  FlickrPictureCollection.swift
//  FlickrPix
//
//  Created by David Gerstl on 4/4/19.
//  Copyright © 2019 Farmingdale State College. All rights reserved.
//

import UIKit

class FlickrPictureCollection {
    var currentPhotos: Array<FlickrPicture>?

  
    // MARK: user facing methods:
    // only stubs so far
    func getPictureAt(row: Int)->FlickrPicture? {
        return currentPhotos?[row]
    }
    private enum URLAction {
        case Recent
        case Search(String)
    }
    private func generateURL(action: URLAction)->URL {
        let baseURL = "https://api.flickr.com/services/rest/"
        var urlComponents = URLComponents(string: baseURL)!
        var queryItemArrays=Array<URLQueryItem>()
        switch action {
        case .Recent:
            queryItemArrays.append(URLQueryItem(name: "method", value: "flickr.photos.getRecent"))
        case .Search(let searchTerm):
            queryItemArrays.append(URLQueryItem(
                name: "method",
                value: "flickr.photos.search"))
            queryItemArrays.append(URLQueryItem(
                name: "text",
                value: searchTerm))
        }

        queryItemArrays.append(URLQueryItem(name: "format", value: "json"))
        queryItemArrays.append(URLQueryItem(name: "nojsoncallback", value: "1"))
        queryItemArrays.append(URLQueryItem(name: "extras", value: "date_taken,url_h,url_t,descriptions"))
        queryItemArrays.append(URLQueryItem(name: "safe_search", value: "1"))
        queryItemArrays.append(URLQueryItem(name: "api_key", value: GlobalConstants.APIKey.flickAPIKey))
        urlComponents.queryItems = queryItemArrays
        print(urlComponents.string!)
        return urlComponents.url!
    }
    
    public func getPicturesData(url: URL, completionHandler: (()->())?) {
        // 2. retrieve the data
        let session = URLSession(configuration: .ephemeral)
        let task = session.dataTask(with: url) {
            // completion handler using trailing closure syntax
            (data, response, error) in
            var localPhotos = Array<FlickrPicture>()
            // write some code here
            print("I'm in \(#file) at line \(#line)")
            if let actualError = error {
                print("I got an error: \(actualError)")
            } else if let actualResponse = response,
                let actualData = data,
                let parsedData = try? JSON(data: actualData) {
                print("I got some data: \(actualData)")
                
                // print("I got some data: \(parsedData)")
                let thePhotos = parsedData["photos"]
                let theRealPhotos = thePhotos["photo"]
                for (_, aPhoto) in theRealPhotos {
                    print("I got a photo: \(aPhoto)")
                    if let theURLt = aPhoto["url_t"].url,
                        let theURLh = aPhoto["url_h"].url,
                        let theOwner = aPhoto["owner"].string,
                        let theTitle = aPhoto["title"].string,
                        let theStringID = aPhoto["id"].string,
                        let theID = Int(theStringID)
                    {
                        // 3. parse the data: Convert JSON to a usable structure
                        // let parsedData = try? JSON(data: ???)
                        // 4. fill my array of FlickPictures with the data from (3)
                        var aFlickrPic = FlickrPicture(
                            id: theID,
                            owner: theOwner,
                            title: theTitle,
                            urlT: theURLt,
                            urlH: theURLh,
                            dateTaken: nil)
                        localPhotos.append(aFlickrPic)
                     
                    }
                }
                // print("I got some data: \(theRealPhotos)")
                self.currentPhotos = localPhotos
            }
            print("Done with Closure. \(localPhotos.count) rows")
            // If there is a completionHandler, dispatch it to the main thread
            DispatchQueue.main.async {
                completionHandler?()
            }
        } // End of Closure for session.dataTask()
        // the task is created stopped. We need to start it.
        print("I'm in \(#file) at line \(#line)")
        task.resume()
        print("I'm in \(#file) at line \(#line)")
        // conditional unwrap
    }
   
    
    // This method will fill currentPhotos with recent photos
    func getRecent(completionHandler: (()->())? = nil) {
        // 1. generate a URL to get the data
        let theURL = generateURL(action: .Recent)
        getPicturesData(url: theURL, completionHandler: completionHandler)
    }
    // This method will fill currentPhotos with photos related to search term
    func getWith(searchTerm: String, completionHandler: (()->())? = nil) {
        currentPhotos = Array<FlickrPicture>()
        // 1. generate a URL to get the data
        let theURL = generateURL(action: .Search(searchTerm))
        getPicturesData(url: theURL, completionHandler: completionHandler)
    }
    // done
    func getPictureCount()->Int {
        return currentPhotos?.count ?? 0
    }
    init(){
        // where there's a memory warning, call proper method
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(receivedMemoryWarning),
            name: UIApplication.didReceiveMemoryWarningNotification,
            object: nil)
    }
    deinit {
        // cancel all of our subscriptions. We're going to Fla for the winter
        NotificationCenter.default.removeObserver(self)
    }
    // MARK: internal methods
    // clean up my photos to reduce memory footprint
    @objc func receivedMemoryWarning(){
        if nil != currentPhotos {
            for pic in currentPhotos! {
              
                pic.thumbnail = nil
            }
        }
    }
    
}
