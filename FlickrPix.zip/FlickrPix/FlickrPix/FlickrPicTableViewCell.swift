//
//  FlickrPicTableViewCell.swift
//  FlickrPix
//
//  Created by David Gerstl on 4/18/19.
//  Copyright © 2019 Farmingdale State College. All rights reserved.
//

import UIKit

class FlickrPicTableViewCell: UITableViewCell {

    @IBOutlet weak var theImage: UIImageView!
    @IBOutlet weak var TheActivityController: UIActivityIndicatorView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
