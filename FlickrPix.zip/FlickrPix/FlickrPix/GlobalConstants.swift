//
//  GlobalConstants.swift
//  FlickrPix
//
//  Created by David Gerstl on 4/9/19.
//  Copyright © 2019 Farmingdale State College. All rights reserved.
//

import Foundation

class GlobalConstants {
    // API key for Flickr
    struct APIKey {
        static let flickAPIKey = "63780ffe405122cc9fcf571b9c9bcf2f"
    }
    
}
