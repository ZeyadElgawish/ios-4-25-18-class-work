//
//  FlickrPicture.swift
//  FlickrPix
//
//  Created by David Gerstl on 4/4/19.
//  Copyright © 2019 Farmingdale State College. All rights reserved.
//

import UIKit

class FlickrPicture {
    var id: Int // id of the photo
    var owner: String // owner of the photo
    var title: String // titles
    var urlT: URL // url of the thumbnail
    var urlH: URL // url of the high resolution picture
    var dateTaken: Date? 
    var thumbnail: UIImage?
    lazy var bigPicture: UIImage? = {
            // add some code
            return nil
    }() // the extra () are needed
    func getThumbnail(completionHandler: (()->())? = nil)->UIImage? {
        // 1. if the thumbnail exists, return it.
        if thumbnail != nil {
            return thumbnail
        }
        // 2. if the thumbnail is blank
        //      (a) try to make a data task
        let session = URLSession(configuration: .ephemeral)
        let task = session.dataTask(with: urlT) {
            (data, response, error) in
            //      (b) get the tn data,
            if let actualError = error {
                print("Got an error in \(#file), line \(#line)")
            } else if let actualResponse = response,
                let actualData = data,
                let actualImage = UIImage(data: actualData) {
                //      (c) create a UIImage,
                //      (d) set the TN
                self.thumbnail = actualImage
                //      (e) and call the CH
                // If there is a completionHandler, dispatch it to the main thread
                DispatchQueue.main.async {
                    completionHandler?()
                }
            }
        } // completionHandler end
        task.resume()
        return thumbnail
    }
    
    init(id: Int,
         owner: String,
         title: String,
         urlT: URL,
         urlH: URL,
         dateTaken: Date?){
        self.id = id // set the class value to the param value
        self.owner = owner
        self.title = title
        self.urlH = urlH
        self.urlT = urlT
        self.dateTaken = dateTaken
    }
    
}
